https://github.com/Egor1001/zakrivayuschiy-teg-f
https://www.figma.com/design/w2xSZuydbaTSe0GyNHBWeo/4-спринт.-Проектная-работа?node-id=0-851&node-type=frame&t=aXIWVxp3jJBQly6x-0